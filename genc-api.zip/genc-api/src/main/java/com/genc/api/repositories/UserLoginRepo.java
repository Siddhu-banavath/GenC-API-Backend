package com.genc.api.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genc.api.entities.UserLogin;



public interface UserLoginRepo extends JpaRepository<UserLogin, Long> {
	
	Optional<UserLogin> findByEmail(String email);

}
