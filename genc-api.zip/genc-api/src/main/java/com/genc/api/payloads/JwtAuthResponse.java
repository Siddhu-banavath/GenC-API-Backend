package com.genc.api.payloads;

import lombok.Data;

@Data
public class JwtAuthResponse {
	
	private String token;
	
	private UserLoginDto userLogin;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public UserLoginDto getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(UserLoginDto userLogin) {
		this.userLogin = userLogin;
	}
	
}

