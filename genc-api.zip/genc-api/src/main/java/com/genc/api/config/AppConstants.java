package com.genc.api.config;

public class AppConstants {
	
	public static final Integer ROLE_ADMIN = 501;
//	public static final Integer ROLE_NORMAL= 502;

}
