package com.genc.api.services;

import java.util.List;

import com.genc.api.payloads.UserLoginDto;




public interface UserLoginService {
	
	UserLoginDto registerNewUser(UserLoginDto userLogin);
	
	UserLoginDto createUserLogin(UserLoginDto userLoginDto);
	UserLoginDto updateUserLogin(UserLoginDto userLoginDto, Long userId);
	UserLoginDto getUserLoginById(Long userId);
	List<UserLoginDto> getAllUserLoginDto();
	void deleteUserLogin(Long userId);

	

	
}

