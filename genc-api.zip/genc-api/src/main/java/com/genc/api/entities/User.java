package com.genc.api.entities;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user", uniqueConstraints = {@UniqueConstraint(columnNames = {"associateId"})})
@NoArgsConstructor
@Getter
@Setter
public class User {
	
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    
    @Id
    private long associateId;

    private String associateName;

    private String projectId;

    private String projectName;

    private String customerName;

    private String skill;

    private String associateCity;

    private String homeManagerName;

    private String mentorName;

    private String currentStatus;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date LastUpdate;
    
    @PrePersist
    private void onCreate() {
    	LastUpdate = new Date();
    }
    


	public User(int id, Long associateId, String associateName, String projectId, String projectName,
			String customerName, String skill, String associateCity, String homeManagerName, String mentorName,
			String currentStatus) {
		super();
		this.id = id;
		this.associateId = associateId;
		this.associateName = associateName;
		this.projectId = projectId;
		this.projectName = projectName;
		this.customerName = customerName;
		this.skill = skill;
		this.associateCity = associateCity;
		this.homeManagerName = homeManagerName;
		this.mentorName = mentorName;
		this.currentStatus = currentStatus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getAssociateId() {
		return associateId;
	}

	public void setAssociateId(Long associateId) {
		this.associateId = associateId;
	}

	public String getAssociateName() {
		return associateName;
	}

	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getAssociateCity() {
		return associateCity;
	}

	public void setAssociateCity(String associateCity) {
		this.associateCity = associateCity;
	}

	public String getHomeManagerName() {
		return homeManagerName;
	}

	public void setHomeManagerName(String homeManagerName) {
		this.homeManagerName = homeManagerName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}



	public Date getLastUpdate() {
		return LastUpdate;
	}



	public void setLastUpdate(Date lastUpdate) {
		LastUpdate = lastUpdate;
	}



	public User(long associateId, String associateName, String projectId, String projectName, String customerName,
			String skill, String associateCity, String homeManagerName, String mentorName, String currentStatus,
			Date lastUpdate) {
		super();
		this.associateId = associateId;
		this.associateName = associateName;
		this.projectId = projectId;
		this.projectName = projectName;
		this.customerName = customerName;
		this.skill = skill;
		this.associateCity = associateCity;
		this.homeManagerName = homeManagerName;
		this.mentorName = mentorName;
		this.currentStatus = currentStatus;
		LastUpdate = lastUpdate;
	}


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

	
	

	
	
	
    
    

}