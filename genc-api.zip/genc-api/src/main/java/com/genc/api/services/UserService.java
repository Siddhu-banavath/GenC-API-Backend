package com.genc.api.services;

import java.util.List;

import com.genc.api.payloads.UserDto;


public interface UserService {
	
	UserDto createUser(UserDto userDto);
	UserDto updateUser(UserDto userDto, Long associateId);
	UserDto getUserById(Long associateId);
	List<UserDto> getAllUserDto();
	void deleteUser(Long associateId);

}

