package com.genc.api.payloads;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter
public class UserDto {
	
	
	private int id;
    
    private long associateId;

	@NotEmpty
	@Size(min = 4, message = "asso_name must be min of 4 characters !!")
    private String associateName;

	@NotEmpty
    private String projectId;

	@NotEmpty
    private String projectName;

	@NotEmpty
    private String customerName;

	@NotEmpty
    private String skill;

	@NotEmpty
    private String associateCity;

	@NotEmpty
    private String homeManagerName;

	@NotEmpty
    private String mentorName;

	@NotEmpty
    private String currentStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
    private Date LastUpdate;
    
	@PrePersist
    private void onCreate() {
    	LastUpdate = new Date();
    }

	public UserDto(int id, Long associateId, String associateName,
			 String projectId, String projectName,  String customerName,
			 String skill, String associateCity, String homeManagerName,
			 String mentorName,  String currentStatus) {
		super();
		this.id = id;
		this.associateId = associateId;
		this.associateName = associateName;
		this.projectId = projectId;
		this.projectName = projectName;
		this.customerName = customerName;
		this.skill = skill;
		this.associateCity = associateCity;
		this.homeManagerName = homeManagerName;
		this.mentorName = mentorName;
		this.currentStatus = currentStatus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getAssociateId() {
		return associateId;
	}

	public void setAssociateId(Long associateId) {
		this.associateId = associateId;
	}

	public String getAssociateName() {
		return associateName;
	}

	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getAssociateCity() {
		return associateCity;
	}

	public void setAssociateCity(String associateCity) {
		this.associateCity = associateCity;
	}

	public String getHomeManagerName() {
		return homeManagerName;
	}

	public void setHomeManagerName(String homeManagerName) {
		this.homeManagerName = homeManagerName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public Date getLastUpdate() {
		return LastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		LastUpdate = lastUpdate;
	}

	public UserDto(long associateId,
			@NotEmpty @Size(min = 4, message = "asso_name must be min of 4 characters !!") String associateName,
			@NotEmpty String projectId, @NotEmpty String projectName, @NotEmpty String customerName,
			@NotEmpty String skill, @NotEmpty String associateCity, @NotEmpty String homeManagerName,
			@NotEmpty String mentorName, @NotEmpty String currentStatus, Date lastUpdate) {
		super();
		this.associateId = associateId;
		this.associateName = associateName;
		this.projectId = projectId;
		this.projectName = projectName;
		this.customerName = customerName;
		this.skill = skill;
		this.associateCity = associateCity;
		this.homeManagerName = homeManagerName;
		this.mentorName = mentorName;
		this.currentStatus = currentStatus;
		LastUpdate = lastUpdate;
	}

	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
	
	

	
	

}
